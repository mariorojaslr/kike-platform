<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('escuelas', function (Blueprint $table) {
            $table->id();
            $table->string('nombre');
            $table->string('cue')->nullable();
            $table->string('direccion')->nullable();
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('escuelas'); }
};
